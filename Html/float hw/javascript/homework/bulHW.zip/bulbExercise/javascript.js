var s = 
`Lorem ipsum dolor sit amet, consectetur adipisicing elit. HackerU Numquam, dolor cum odit minima expedita veniam autem facere quisquam, deserunt non rem natus consectetur enim repellendus soluta aspernatur! Rerum, laudantium ab.`;

console.log(`Lorem ipsum dolor sit amet, consectetur adipisicing elit. HackerU Numquam, dolor cum odit minima expedita veniam autem facere quisquam, deserunt non rem natus consectetur enim repellendus soluta aspernatur! Rerum, laudantium ab.`);

console.log(s.indexOf("HackerU"));