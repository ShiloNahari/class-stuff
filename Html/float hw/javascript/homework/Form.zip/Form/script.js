function save () {
    console.log(client)
}

var client = {}

function input(name,value){
    client[name]=value;
}