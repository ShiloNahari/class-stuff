"use strict"
{
 
    var sumA = 15,
    sumB = -2;
    console.log (sumA+sumB)
    
    var loverName = "what "
    var haterName = "the..."

    console.log (loverName + haterName)
    document.getElementById("nani").innerText = sumA + sumB;
}
{
    var carName = "volvo", 
    x = 50, 
    z = 5, 
    y = 10,
    m = x + y,
    g = z + y;
    
    window.alert(m)
    document.getElementById("fifteen").innerHTML=(g)


}

// {
//     //age calculator
//     var yearBorn = 1994;
//     var yearToBe = 2029;
//     var howOld = yearToBe-yearBorn;
//     console.log('you will be either '  + howOld + " " + 'or' + " " +  (howOld-1))
// }
// {
//     //lifetime supply calculator
//     var currentAge = 27,
//     maxAge = 83, 
//     estimatedAmountPerDay = 2, 
//     totalPerLifetime = (maxAge - currentAge) * estimatedAmountPerDay * 365
//     console.log ("You will need " + totalPerLifetime + "-ish" + " candy to last you until the ripe old age of " + maxAge)
// }
// {
//     //The Geometrizer
//     var radiusOfCircle = 13, 
//     PI = 3.141592,
//     diameter = 2 * radiusOfCircle, 
//         //area Of Circle:
//     area = PI*radiusOfCircle**2,
//         //Circumference of Circle 
//     Circumference = PI * diameter
//     console.log("The circumference is " + Circumference + " CM")
//     console.log ("The area is " + area + " CM")
// }