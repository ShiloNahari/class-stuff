function Trapezoid(base1,base2, height){
    var base1 = 0,
        base2 = 0,
        height = 0;
    var area = ((base1 + base2) * height)/2;
        
    console.log("The area of a Trapezoid is " + area)
}

function helloWorld(stuffHere){
    alert("hello world" + stuffHere)
}

function jelloWorld(){
    alert("hello world")
}
